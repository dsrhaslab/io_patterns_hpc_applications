#!/bin/sh
#SBATCH --job-name=install_monarch
#SBATCH --time=48:00:00
#SBATCH --account=i20240002g
#SBATCH --partition=normal-a100-80

module load Python/3.9.5-GCCcore-10.3.0
source /projects/I20240002/andrelucena/tensorflow-venv2/bin/activate
python /projects/I20240002/andrelucena/ScriptVault/TFScripts/models/official-models-2.1.0/official/r1/resnet/cifar10_download_and_extract.py --data_dir="/projects/I20240002/andrelucena/"