#!/bin/bash

salloc -A I20240002g -p normal-a100-40 -N 2 -t 48:00:00