#!/bin/bash
#SBATCH -J dist-monarch       # Job name
#SBATCH -o dist-monarch.out%j   # Name of stdout output file
#SBATCH -e dist-monarch.err%j   # Name of stderr error file
#SBATCH -N 2                  # Total # of nodes (must be 1 for serial)
#SBATCH -n 2                  # Total # of mpi tasks (should be 1 for serial)
#SBATCH -t 01:00:00           # Run time (hh:mm:ss)

SCRIPTS_PATH=/fs/scratch/franl08/ScriptVault/TFScripts/models/official-models-2.1.0/official/vision/image_classification/
SINGLE_JOB_SCRIPT_NAME=run_slurm.sh
PROFILE_PATH=/etc/profile
HOME_DIR=/fs/scratch/franl08

WRKS_ADDRS=$(./get_ips_slurm.sh)
echo ${WRKS_ADDRS}
nodes=($(scontrol show hostnames ${SLURM_JOB_NODELIST} | sort | uniq ))
numnodes=${#nodes[@]}
last=$(( $numnodes - 1 ))
out="$(getent hosts ${nodes[0]} | awk '{print $1}')"

MODEL_ID=5
BATCH_SIZE=512
N_EPOCHS=2
for i in $(seq 0 $last )
do
        ssh $(getent hosts ${nodes[$i]} | awk '{print $3}' | head -1) "source ${PROFILE_PATH}; export WRKS_ADDRS=${WRKS_ADDRS}; cd ${SCRIPTS_PATH}; ./${SINGLE_JOB_SCRIPT_NAME} ${i} ${MODEL_ID} ${BATCH_SIZE} ${N_EPOCHS}" >$HOME_DIR/stdout_$i.txt 2>$HOME_DIR/stderr_$i.txt &
        pids[${i}]=$!
done
# wait for all processes to finish
for pid in ${pids[*]}
do 
        wait $pid 
done
