import gdb

my_stop_request = False

def do_continue():
    print("[GDB] before continue")
    gdb.execute("continue")
    print("[GDB] after continue")

def switch_inferior(x):
    print("[GDB] before inferior")
    gdb.execute("inferior %d" % x)
    print("[GDB] after inferior")

def perform(fun, *args):
    print("[GDB] Perform invoked, before")
    fun(*args)
    print("[GDB] Perform invoked, before")

def exit_handler(event):
    global my_stop_request
    print("[GDB] Exit Handler")
    has_threads = [ inferior.num for inferior in gdb.inferiors() if inferior.threads() ]
    print(f"[GDB] {has_threads}")
    if has_threads:
        has_threads.sort()
        inferior = f"inferior {has_threads[0]}"
        gdb.post_event(lambda: gdb.execute('printf "[GDB] Execute works well"\n'))
        print(f"[GDB] After Execute {has_threads}")
        my_stop_request = True

def stop_handler(event):
    global my_stop_request
    print("[GDB] Stop Handler")
    if isinstance(event, gdb.SignalEvent):
        pass
    elif isinstance(event, gdb.BreakpointEvent):
        pass
    elif my_stop_request:
        my_stop_request = False
        gdb.post_event(do_continue)

gdb.events.stop.connect(stop_handler)
gdb.events.exited.connect(exit_handler)
print("[GDB] Handler activated")

gdb.execute("set exec-wrapper env 'LD_PRELOAD=/projects/I20240002/andrelucena/DistMonarch/pastor/build/libmonarch.so'")
gdb.execute("set detach-on-fork off")
gdb.execute("set schedule-multiple on")
gdb.execute("set follow-fork-mode parent")
gdb.execute("set non-stop on")
gdb.execute("set logging enabled off")
gdb.execute("set print symbol-loading off")
gdb.execute("run")
