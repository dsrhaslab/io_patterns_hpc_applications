#!/bin/bash

module load Python/3.8.2 # for slurm to use python correct version
source $HOME/tensorflow-venv2/bin/activate
echo "run_slurm.sh"
SCRATCH="/fs/scratch/franl08"

# script usage: bash run.sh <POSITION_OF_WORKER_IN_WRKS_ADDRS> <NUMBER_OF_THE_DESIRED_MODEL> <BATCH_SIZE> <N_EPOCHS> 
MODEL_NUMBER=0
BATCH_SIZE=512
N_EPOCHS=4
TASK_ID=0
# OPTIMIZER=$5 -> a beatriz falou disto, mas nos scripts dela nunca usa...

rm -r /tmp/train/
rm -r /tmp/middleware_output
ml load NCCL/2.9.9-CUDA-11.3.1 cuDNN/8.2.1.32-CUDA-11.3.1

export PYTHONPATH=$PYTHONPATH:/home/acg16618zc/ScriptVault/TFScripts/models/official-models-2.1.0

DATA_DIR="/home/acg16618zc/openimages/train"

MODEL=""

if [ $MODEL_NUMBER == 0 ]
then
	MODEL="sns_vgg19.py"

elif [ $MODEL_NUMBER == 1 ]
then
        MODEL="sns_inceptionv3.py"

elif [ $MODEL_NUMBER == 2 ]
then
        MODEL="sns_shufflenet.py"

elif [ $MODEL_NUMBER == 3 ]
then
        MODEL="sns_resnet18.py"

elif [ $MODEL_NUMBER == 4 ]
then
        MODEL="sns_lenet.py"

elif [ $MODEL_NUMBER == 5 ]
then
        MODEL="sns_alexnet.py"

fi

LOG_PATH="/tmp/log_$TASK_ID.txt"

python $MODEL --skip_eval --train_epochs=$N_EPOCHS --batch_size=$BATCH_SIZE --model_dir="/tmp/checkpointing" --data_dir=$DATA_DIR --task_index=$TASK_ID --num_gpus=1 # |& tee $LOG_PATH  
