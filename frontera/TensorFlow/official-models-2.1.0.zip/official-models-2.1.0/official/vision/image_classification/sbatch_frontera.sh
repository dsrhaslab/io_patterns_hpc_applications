#!/bin/sh

export SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]:-$0}" )" &> /dev/null && pwd )
export HOME_DIR=$HOME
export OUTPUT_DIR="$SCRATCH/output"

sbatch multi_run_wrapper_frontera.sh