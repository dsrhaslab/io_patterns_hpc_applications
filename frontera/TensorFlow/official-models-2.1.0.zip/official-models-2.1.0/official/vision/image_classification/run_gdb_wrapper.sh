#!/bin/sh
#if [ -z "$TASK_ID" -o -z "$WRKS_ADDRS" ] ; then
#        echo "Don't forget to export TASK_ID and WRKS_ADDRS"
#else

        if [ ! -z $1 ] ; then
                export TASK_ID=$1
        fi
        SCRIPTS_PATH=/projects/I20240002/andrelucena/ScriptVault/TFScripts/models/official-models-2.1.0/official/vision/image_classification/
        #PROFILE_PATH=/etc/profile
        HOME_DIR=/projects/I20240002/andrelucena
        SCRATCH=$HOME_DIR

        MODEL_NUMBER=3 #0-vgg19, 1-incenptionv3, 2-shufflenet, 3-resnet18, 4-lenet, 5-alexnet SÓ O RESNET É QUE NÃO ESTÁ A FAZER MAU SHARDING
        BATCH_SIZE=256
        N_EPOCHS=2
        DISTRIBUTION_STRATEGY="multi_worker_mirrored" # "mirrored", "one_device", "parameter_server", "multi_worker_mirrored"
        DATASET="imagenet" # "imagenet" "openimages"
        POLICY="hvac"
        if [ $POLICY == "hvac" ] ; then
                POLICY_CONFIG="_hvac"
        fi

        SCRATCH="/projects/I20240002/andrelucena"
        CONFIGS_FOLDER=$SCRATCH/DistMonarch/configurations/deucalion

        # OPTIMIZER=$5 -> a beatriz falou disto, mas nos scripts dela nunca usa...

        TRACE_DIR=/projects/I20240002/andrelucena/trace-collector
        SCRIPT_NAME=wrapper.py

        if [ $DATASET == "imagenet" ] ; then
                DATA_DIR="/projects/I20240002/andrelucena/imagenet/train"  # "/projects/I20240002/franeves08/train" "/projects/I20240002/andrelucena/imagenet/train"
                CONFIG_FILE=tf_placement_100g_disk_imagenet$POLICY_CONFIG.yaml # "tf_placement_100g_disk.yaml" "tf_placement_100g_disk_imagenet.yaml"
        elif [ $DATASET == "openimages" ]; then
                DATA_DIR="/projects/I20240002/franeves08/train"
                CONFIG_FILE=tf_placement_100g_disk$POLICY_CONFIG.yaml
        else
                echo "ERROR CONDITION"
        fi

        export INSTALL_DIR=$SCRATCH/DistMonarch/dependencies
        export MONARCH_DIR=$SCRATCH/DistMonarch/pastor/build
        export MONARCH_CONFIGS_PATH=$CONFIGS_FOLDER/$CONFIG_FILE

        rm -r /tmp/oimages_tfrecords/
        rm -r $SCRATCH/middleware_output

        module load Python/3.9.5 # for slurm to use python correct version
        module load Boost/1.76.0 CUDA/12.4.0 hwloc/2.4.1 NCCL/2.10.3 cuDNN/8.2.1 cmake/3.21.3 GCCcore/10.3.0 GDB
        source /projects/I20240002/andrelucena/tensorflow-venv2/bin/activate

        export PYTHONPATH=$PYTHONPATH:$SCRATCH/ScriptVault/TFScripts/models/official-models-2.1.0

        MODEL=""
        echo $WRKS_ADDRS

        if [ $MODEL_NUMBER == 0 ]
        then
                MODEL="sns_vgg19.py"

        elif [ $MODEL_NUMBER == 1 ]
        then
                MODEL="sns_inceptionv3.py"

        elif [ $MODEL_NUMBER == 2 ]
        then
                MODEL="sns_shufflenet.py"

        elif [ $MODEL_NUMBER == 3 ]
        then
                MODEL="sns_resnet18.py"

        elif [ $MODEL_NUMBER == 4 ]
        then
                MODEL="sns_lenet.py"

        elif [ $MODEL_NUMBER == 5 ]
        then
                MODEL="sns_alexnet.py"

        fi

        LOG_PATH="/tmp/log_$TASK_ID.txt"

        echo "About to run $pwd"
        export HG_LOG_LEVEL=debug
        export HG_LOG_SUBSYS=hg #cls,ctx,hg
        #export FI_LOG_LEVEL=error
        { 
                gdb -x seg_fault.gdb --args python $SCRIPT_NAME $MODEL $N_EPOCHS $BATCH_SIZE $DATA_DIR $TASK_ID $WRKS_ADDRS $DISTRIBUTION_STRATEGY 
        } >> $TASK_ID.txt 2>&1
        #|& tee $LOG_PATH
#fi