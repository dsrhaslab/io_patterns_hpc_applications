#!/bin/sh

export SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]:-$0}" )" &> /dev/null && pwd )

sbatch $SCRIPT_DIR/multi_run_wrapper_deucalion.sh