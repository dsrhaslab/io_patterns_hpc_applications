#!/bin/bash

sbatch ./run.sh 5 512 0 & sbatch ./run.sh 4 512 0 #&


