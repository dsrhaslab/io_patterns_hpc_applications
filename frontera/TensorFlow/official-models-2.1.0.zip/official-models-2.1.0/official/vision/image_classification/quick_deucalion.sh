#!/bin/bash

#SBATCH -J quick           # Job name
#SBATCH -o quick.out%j       # Name of stdout output file
#SBATCH -e quick.err%j       # Name of stderr error file
#SBATCH --time=4:00:00
#SBATCH --account=i20240002a
#SBATCH --partition=dev-arm
#SBATCH -N 1               # Total # of nodes (must be 1 for serial)
#SBATCH -n 1               # Total # of mpi tasks (should be 1 for serial)

rm -rf dist_resnet18_2e_2nodes.*