import socket
import os
import time
import sys
import threading
import subprocess

PORT = 50053
MAX_CONNECTIONS = 100
DATASET_DIR = ""
EPOCHS = 0
BATCH_SIZE = 0
TASK_ID = 0
MODEL = ""
N_WORKERS = 0
DISTRIBUTION_STRATEGY = "one_device"
WRKS_ADDRS = ""
WRKS_LIST = []

received_dones = 0

def receive_info():
    global PORT, N_WORKERS, received_dones
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("", PORT))
    s.listen(9)
    while True:
        c, addr = s.accept()
        data = c.recv(1024)
        if data == b"DONE":
            received_dones += 1
            if received_dones == N_WORKERS:
                break
    s.close()


def send_done(worker):
    global PORT
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect((worker, PORT))
        s.send(b"DONE")
        return True
    except Exception as e:
        print(f"Error: {e}")
        return False


def run():
    global DATASET_DIR, EPOCHS, BATCH_SIZE, TASK_ID, MODEL
    print(f"Wrapper: Starting training with {len(WRKS_LIST)*4} GPUs")
    command = f'python {MODEL} --distribution_strategy={DISTRIBUTION_STRATEGY} --worker_hosts={WRKS_ADDRS} --skip_eval --train_epochs={EPOCHS} --batch_size={BATCH_SIZE} --model_dir="/tmp/checkpointing" --data_dir={DATASET_DIR} --task_index={TASK_ID} --num_gpus={4*len(WRKS_LIST)}'
    subprocess.run(command, shell=True, check=True)


def main():
    global \
        DATASET_DIR, \
        EPOCHS, \
        BATCH_SIZE, \
        TASK_ID, \
        MODEL, \
        N_WORKERS, \
        DISTRIBUTION_STRATEGY, \
        WRKS_ADDRS, \
        WRKS_LIST, \
        received_dones
    workers = os.environ["WRKS_ADDRS"]
    workers = workers.split(",")
    print(f"Workers Addresses: {WRKS_ADDRS}")
    N_WORKERS = len(workers) - 1 # we don't want to receive or send messages to ourselves
    MODEL = sys.argv[1]
    EPOCHS = int(sys.argv[2])
    BATCH_SIZE = int(sys.argv[3])
    DATASET_DIR = sys.argv[4]
    TASK_ID = int(sys.argv[5])
    if len(sys.argv) >= 7:
        WRKS_LIST  = sys.argv[6].split(",")
        WRKS_ADDRS = ":7555,".join(WRKS_LIST) + ":7555"
        if len(sys.argv) >= 8:
            DISTRIBUTION_STRATEGY = sys.argv[7]
    del workers[TASK_ID] # we don't want to receive or send messages to ourselves
    thread = threading.Thread(target=receive_info)
    thread.start()
    run()
    work_done = True
    dones_sent = 0
    for worker in workers:
        while not send_done(worker):
            pass
        dones_sent += 1
    while received_dones < len(workers) or dones_sent < len(workers):
        time.sleep(1)


if __name__ == "__main__":
    main()
