#!/bin/bash
#SBATCH -J check_files       # Job name
#SBATCH -o check_files.out%j   # Name of stdout output file
#SBATCH -e check_files.err%j   # Name of stderr error file
#SBATCH -N 1                  # Total # of nodes (must be 1 for serial)
#SBATCH -n 1                  # Total # of mpi tasks (should be 1 for serial)
#SBATCH -t 48:00:00           # Run time (hh:mm:ss)
#SBATCH --account=i20240002g
#SBATCH --partition=normal-a100-40

module load Python/3.9.5

FILE=/projects/I20240002/andrelucena/ScriptVault/TFScripts/models/official-models-2.1.0/official/vision/image_classification/dist_imagenet_resnet18_2e_2nodes.out351988
FILE_ERR=/projects/I20240002/andrelucena/ScriptVault/TFScripts/models/official-models-2.1.0/official/vision/image_classification/dist_imagenet_resnet18_2e_2nodes.err351988

python check_files_per_worker.py $FILE $FILE_ERR