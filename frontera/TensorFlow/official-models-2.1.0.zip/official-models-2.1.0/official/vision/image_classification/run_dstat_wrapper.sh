#!/bin/bash

echo "run_wrapper.sh"

SCRATCH="/projects/I20240002/andrelucena"
CONFIGS_FOLDER=$SCRATCH/DistMonarch/configurations/deucalion

# script usage: bash run.sh <POSITION_OF_WORKER_IN_WRKS_ADDRS> <NUMBER_OF_THE_DESIRED_MODEL> <BATCH_SIZE> <N_EPOCHS> 
TASK_ID=$1
MODEL_NUMBER=$2
BATCH_SIZE=$3
N_EPOCHS=$4
DISTRIBUTION_STRATEGY=$5
DATASET=$6
# OPTIMIZER=$5 -> a beatriz falou disto, mas nos scripts dela nunca usa...

TRACE_DIR=/projects/I20240002/andrelucena/trace-collector
SCRIPT_NAME=no_wait_wrapper.py

if [ $DATASET == "imagenet" ] ; then
        DATA_DIR="/projects/I20240002/andrelucena/imagenet/train"  # "/projects/I20240002/franeves08/train" "/projects/I20240002/andrelucena/imagenet/train"
        CONFIG_FILE=tf_placement_100g_disk_imagenet.yaml # "tf_placement_100g_disk.yaml" "tf_placement_100g_disk_imagenet.yaml"
elif [ $DATASET == "openimages" ]; then
        DATA_DIR="/projects/I20240002/franeves08/train"
        CONFIG_FILE=tf_placement_100g_disk.yaml
else
        echo "ERROR CONDITION"
fi

export INSTALL_DIR=$SCRATCH/DistMonarch/dependencies
export MONARCH_DIR=$SCRATCH/DistMonarch/pastor/build
export MONARCH_CONFIGS_PATH=$CONFIGS_FOLDER/$CONFIG_FILE
export TASK_ID=$TASK_ID
export DSTAT_PATH="$SCRIPTS_PATH/../../../../../../dstat/"

rm -r /tmp/openimages_tfrecords/
rm -r $SCRATCH/middleware_output

module load Python/3.9.5
module load Boost/1.76.0 CUDA/12.4.0 hwloc/2.4.1 NCCL/2.10.3 cuDNN/8.2.1 cmake/3.21.3 GCCcore/10.3.0
source /projects/I20240002/andrelucena/tensorflow-venv2/bin/activate

export PYTHONPATH=$PYTHONPATH:$SCRATCH/ScriptVault/TFScripts/models/official-models-2.1.0

MODEL=""
echo $WRKS_ADDRS

if [ $MODEL_NUMBER == 0 ]
then
	MODEL="sns_vgg19.py"

elif [ $MODEL_NUMBER == 1 ]
then
        MODEL="sns_inceptionv3.py"

elif [ $MODEL_NUMBER == 2 ]
then
        MODEL="sns_shufflenet.py"

elif [ $MODEL_NUMBER == 3 ]
then
        MODEL="sns_resnet18.py"

elif [ $MODEL_NUMBER == 4 ]
then
        MODEL="sns_lenet.py"

elif [ $MODEL_NUMBER == 5 ]
then
        MODEL="sns_alexnet.py"

fi

if [ $DATASET == "imagenet" ] ; then
        MODEL="imagenet_$MODEL"
fi

TEST_TITLE=$MODEL\_$N_EPOCHS\_$BATCH_SIZE\_$(hostname)
OUTPUT_DIR=$SCRATCH/statistics/$TEST_TITLE

LOG_PATH="/tmp/log_$TASK_ID.txt"

echo "About to run $pwd"

nohup python $DSTAT_PATH/dstat.py -tcdrnmg --ib --noheaders --output $OUTPUT_DIR/dstat.csv
nohup nvidia-smi --query-gpu=timestamp,temperature.gpu,utilization.gpu,utilization.memory,memory.total,memory.free,memory.used --format=csv,nounits -f $OUTPUT_DIR/gpu.csv -l 1

#export NCCL_DEBUG=info
#export LD_LIBRARY_PATH=/eb/x86_64/software/GCCcore/13.3.0/lib64:$LD_LIBRARY_PATH
#LD_PRELOAD=$TRACE_DIR/build/libpadll.so:/eb/x86_64/software/GCCcore/13.3.0/lib64/libstdc++.so.6 \

#export HG_LOG_LEVEL=error
#export HG_LOG_SUBSYS=cls,ctx,hg
#export FI_LOG_LEVEL=error
LD_PRELOAD=$SCRATCH/DistMonarch/pastor/build/libmonarch.so \
python $SCRIPT_NAME $MODEL $N_EPOCHS $BATCH_SIZE $DATA_DIR $TASK_ID $WRKS_ADDRS $DISTRIBUTION_STRATEGY 

#|& tee $LOG_PATH