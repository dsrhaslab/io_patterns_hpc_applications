#!/bin/bash

module load Python/3.8.2 # for slurm to use python correct version
source $HOME/tensorflow-venv2/bin/activate
echo "run_slurm.sh"
SCRATCH="/fs/scratch/franl08"
CONFIGS_FOLDER=$SCRATCH/DistMonarch/configurations/slurm
CONFIG_FILE=tf_placement_100g_disk.yaml

# script usage: bash run.sh <POSITION_OF_WORKER_IN_WRKS_ADDRS> <NUMBER_OF_THE_DESIRED_MODEL> <BATCH_SIZE> <N_EPOCHS> 
TASK_ID=$1
MODEL_NUMBER=$2
BATCH_SIZE=$3
N_EPOCHS=$4
# OPTIMIZER=$5 -> a beatriz falou disto, mas nos scripts dela nunca usa...

export INSTALL_DIR=$SCRATCH/dependencies
export MONARCH_DIR=$SCRATCH/DistMonarch/pastor/build
export MONARCH_CONFIGS_PATH=$CONFIGS_FOLDER/$CONFIG_FILE
export TASK_ID=$TASK_ID

rm -r /tmp/100g_tfrecords/
rm -r /tmp/middleware_output
ml load NCCL/2.9.9-CUDA-11.3.1 cuDNN/8.2.1.32-CUDA-11.3.1  CMake/3.24.2-GCCcore-9.1.0 hwloc/1.11.12-GCCcore-9.1.0 GCC/9.1.0-2.32 GCCcore/9.1.0 Boost/1.74.0-GCC-9.1.0

export PYTHONPATH=$PYTHONPATH:$SCRATCH/ScriptVault/TFScripts/models/official-models-2.1.0

DATA_DIR="$SCRATCH/100g_tfrecords"

MODEL=""
echo $WRKS_ADDRS

if [ $MODEL_NUMBER == 0 ]
then
	MODEL="sns_vgg19.py"

elif [ $MODEL_NUMBER == 1 ]
then
        MODEL="sns_inceptionv3.py"

elif [ $MODEL_NUMBER == 2 ]
then
        MODEL="sns_shufflenet.py"

elif [ $MODEL_NUMBER == 3 ]
then
        MODEL="sns_resnet18.py"

elif [ $MODEL_NUMBER == 4 ]
then
        MODEL="sns_lenet.py"

elif [ $MODEL_NUMBER == 5 ]
then
        MODEL="sns_alexnet.py"

fi

LOG_PATH="/tmp/log_$TASK_ID.txt"

LD_PRELOAD=/fs/scratch/franl08/DistMonarch/pastor/build/libmonarch.so python $MODEL --skip_eval --train_epochs=$N_EPOCHS --batch_size=$BATCH_SIZE --model_dir="/tmp/checkpointing" --data_dir=$DATA_DIR --task_index=$TASK_ID --num_gpus=1 # |& tee $LOG_PATH  
