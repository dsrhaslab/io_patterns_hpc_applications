#!/bin/bash

# Needs exported: WRKS_ADDRS TEST_TITLE HOME_DIR WORK_DIR SCRATCH NODE_LOCAL_STORAGE MACHINE
# Needs module load

export SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]:-$0}" )" &> /dev/null && pwd )

# script usage: bash run.sh <POSITION_OF_WORKER_IN_WRKS_ADDRS> <NUMBER_OF_THE_DESIRED_MODEL> <BATCH_SIZE> <N_EPOCHS> 
TASK_ID=$1
MODEL_NUMBER=$2
BATCH_SIZE=$3
N_EPOCHS=$4
DISTRIBUTION_STRATEGY=$5
DATASET=$6
POLICY=$7
if [ $POLICY == "hvac" ] ; then
        POLICY_CONFIG="_hvac"
fi
PROFILING=$8
DEBUG=$9
# OPTIMIZER=$5 -> a beatriz falou disto, mas nos scripts dela nunca usa...

SCRIPT_NAME=no_wait_wrapper.py
CONFIGS_FOLDER=$WORK_DIR/DistMonarch/configurations/$MACHINE

echo $DATASET

if [ $DATASET == "imagenet" ] ; then
        DATA_DIR="$WORK_DIR/imagenet/train"  # "/projects/I20240002/franeves08/train" "/projects/I20240002/andrelucena/imagenet/train"
        CONFIG_FILE=tf_placement_100g_disk_imagenet$POLICY_CONFIG # "tf_placement_100g_disk.yaml" "tf_placement_100g_disk_imagenet.yaml"
elif [ $DATASET == "openimages" ]; then
        DATA_DIR="$WORK_DIR/train"
        CONFIG_FILE=tf_placement_100g_disk$POLICY_CONFIG
else
        echo "ERROR CONDITION"
fi

if [ $DEBUG == "true" ] ; then
        CONFIG_FILE=${CONFIG_FILE}_debug
fi

echo $CONFIG_FILE

export INSTALL_DIR=$WORK_DIR/DistMonarch/dependencies
export MONARCH_DIR=$WORK_DIR/DistMonarch/pastor/build
export MONARCH_CONFIGS_PATH=$CONFIGS_FOLDER/${CONFIG_FILE}.yaml
export TASK_ID=$TASK_ID
export DSTAT_PATH="$SCRIPT_DIR/../../../../../../dstat/"

echo $MONARCH_CONFIGS_PATH

rm -r $NODE_LOCAL_STORAGE/oimages_tfrecords/
if [ $DEBUG == "true" ] ; then
        rm -r $NODE_LOCAL_STORAGE/middleware_output/
fi

export PYTHONPATH=$PYTHONPATH:$WORK_DIR/ScriptVault/TFScripts/models/official-models-2.1.0

MODEL=""
echo $WRKS_ADDRS

if [ $MODEL_NUMBER == 0 ]
then
	MODEL="sns_vgg19.py"

elif [ $MODEL_NUMBER == 1 ]
then
        MODEL="sns_inceptionv3.py"

elif [ $MODEL_NUMBER == 2 ]
then
        MODEL="sns_shufflenet.py"

elif [ $MODEL_NUMBER == 3 ]
then
        MODEL="sns_resnet18.py"

elif [ $MODEL_NUMBER == 4 ]
then
        MODEL="sns_lenet.py"

elif [ $MODEL_NUMBER == 5 ]
then
        MODEL="sns_alexnet.py"

fi

if [ $DATASET == "imagenet" ] ; then
        MODEL="imagenet_$MODEL"
fi

LOG_PATH="/tmp/log_$TASK_ID.txt"

echo "About to run $pwd"

HOSTNAME=$(hostname)
echo $HOSTNAME

# Profiling tools
if [ $PROFILING == "true" ] ; then 
        export DSTAT_PATH="$SCRIPT_DIR/../../../../../../dstat"
        export PROFILING_DIR="$NODE_LOCAL_STORAGE/tst"

        mkdir -p $PROFILING_DIR/
        touch $PROFILING_DIR/srun_dstat_$HOSTNAME.log
        touch $PROFILING_DIR/srun_nvidia_$HOSTNAME.log

        nohup python $DSTAT_PATH/dstat_rita.py -tcdrnmg --ib --noheaders --output $PROFILING_DIR/srun_dstat_$HOSTNAME.log > /dev/null 2>&1 &

        LOGFILE="$PROFILING_DIR/srun_nvidia_$HOSTNAME.log"
        {
                echo "timestamp [ms],temperature.gpu [%],utilization.gpu [%],utilization.memory [%],memory.total [MiB],memory.free [MiB],memory.used [MiB]"
                nvidia-smi --query-gpu=timestamp,temperature.gpu,utilization.gpu,utilization.memory,memory.total,memory.free,memory.used \
                        --format=csv,nounits,noheader -l 1 | \
                awk -F", " -v OFS=", " "{
                split(\$1, dt, /[/ :.]/);
                epoch_sec = mktime(dt[1] \" \" dt[2] \" \" dt[3] \" \" dt[4] \" \" dt[5] \" \" dt[6]);
                timestamp_ms = epoch_sec * 1000 + dt[7];
                \$1 = timestamp_ms;
                print;
                fflush();
                }"
        } > "$LOGFILE" 2>&1 &
fi

#export HG_LOG_LEVEL=error
#export HG_LOG_SUBSYS=cls,ctx,hg
#export FI_LOG_LEVEL=error
if [ $POLICY != "none" ] ; then
        export LD_PRELOAD=$WORK_DIR/DistMonarch/pastor/build/libmonarch.so
fi

#--show-leak-kinds=all -s --leak-check=full --vgdb=full \
#gdb -x seg_fault.gdb --args  \
#valgrind --log-file="$SCRIPT_DIR/$TASK_ID.valgrind" --trace-children=yes --track-origins=yes --max-threads=1000 \
python $SCRIPT_NAME $MODEL $N_EPOCHS $BATCH_SIZE $DATA_DIR $TASK_ID $WRKS_ADDRS $DISTRIBUTION_STRATEGY

unset LD_PRELOAD

if [ $PROFILING == "true" ] ; then 
        export PROFILING_DIR="$NODE_LOCAL_STORAGE/tst"
        sh $SCRIPT_DIR/../../../../../../tracer/stabilize_traces.sh $PROFILING_DIR $WORK_DIR/$TEST_TITLE/$HOSTNAME/
        killall nvidia-smi
        killall python
fi

if [ $DEBUG == "true" ] ; then
        mkdir -p $WORK_DIR/middleware_output/debugger
        mv $NODE_LOCAL_STORAGE/middleware_output/debugger/* $WORK_DIR/middleware_output/debugger
fi
