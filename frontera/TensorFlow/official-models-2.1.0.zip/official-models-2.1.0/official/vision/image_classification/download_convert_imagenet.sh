#!/bin/bash
#SBATCH -J download_imagenet       # Job name
#SBATCH -o download_imagenet.out%j   # Name of stdout output file
#SBATCH -e download_imagenet.err%j   # Name of stderr error file
#SBATCH -N 1                  # Total # of nodes (must be 1 for serial)
#SBATCH -n 1                  # Total # of mpi tasks (should be 1 for serial)
#SBATCH -t 48:00:00           # Run time (hh:mm:ss)
#SBATCH -p flex

module load python3/3.9.2

source ~/tf-venv/bin/activate

$IMAGENET_DIR=$WORK/

$OUTPUT_DIR=$WORK

python fix_corrupted_images.py

python imagenet_to_gcs.py \
  --raw_data_dir=$IMAGENET_DIR \
  --local_scratch_dir=$OUTPUT_DIR/tf_records \
  --nogcs_upload