import re
import os
import sys

print("Checking files")
print(str(sys.argv[1]))
text_file = open(str(sys.argv[1]), 'r')
err_file = open(str(sys.argv[2]), 'r')

if "imagenet" in sys.argv[1]:
    n_files = 1024
    train_dir = r"/projects/I20240002/andrelucena/imagenet/train/"
else:
    n_files = 5282
    train_dir = r"/projects/I20240002/franeves08/train/"

workers = r"(10\.1?2\.3\.1?[01234])"
files = r"(train-\d{5}-of-0" + str(n_files) + r")"

result_per_worker_file_epoch = dict()
result_placement = dict()
result_information_epoch = dict()
result_information = dict()
result_base_read = dict()
result_base_read_epoch = dict()
result_found = dict()

counter = 0
epoch = 1

def end_of_epoch():
    global result_placement, result_information, result_information_epoch, counter, epoch, result_base_read, result_base_read_epoch, result_per_worker_file_epoch
    all_files = list(range(n_files))

    print("\n\n\n")
    print(f"Epoch {epoch}")
    print(f"Base reads (even if through checking other nodes) done this epoch:")
    print(sorted(result_base_read_epoch.items()))
    print(f"Per worker file distribution for this epoch:")

    temp_partition_check = set()

    for worker in result_per_worker_file_epoch:
        print(f"{worker} : {sorted(result_per_worker_file_epoch[worker])}")
        print(f"Amount of files accessed: {len(result_per_worker_file_epoch[worker])}")
        if not temp_partition_check.isdisjoint(result_per_worker_file_epoch[worker]):
            print(f"This epoch did not define partitions between previous workers and {worker}")
            print(f"\tIntersection: {sorted(temp_partition_check.intersection(result_per_worker_file_epoch[worker]))}")
            print(f"\tNew file accesses: {sorted(result_per_worker_file_epoch[worker].difference(temp_partition_check))}")
            print(f"\tOld file accesses: {sorted(temp_partition_check.difference(result_per_worker_file_epoch[worker]))}")
        temp_partition_check |= result_per_worker_file_epoch[worker]

    not_informed = set()
    for train_file in sorted(result_base_read_epoch):
        if train_file not in result_information_epoch:
            not_informed.add(train_file)
    #    if train_file in result_information:
    #        print(f"IMPORTANT: The previously informed file {train_file} was checked for in nodes this epoch.")

    print(f"Informed placement of the following files:")
    print(sorted(result_information_epoch.items()))
    print(f"The following files were not informed this epoch:")
    print(sorted(not_informed))
    
    for train_file in result_information_epoch:
        if train_file not in result_information:
            result_information[train_file] = set()
        result_information[train_file] |= result_information_epoch[train_file]

    for train_file in result_base_read_epoch:
        if int(train_file.split('-')[1]) in all_files:
            all_files.remove(int(train_file.split('-')[1]))
        if train_file not in result_base_read:
            result_base_read[train_file] = set()
        result_base_read[train_file] |= result_base_read_epoch[train_file]

    print("Missing file number requests from other nodes and base reads for this epoch:")
    print(sorted(all_files))
    print(f"Ratio between missed file requests and total number of files: {len(all_files) / float(n_files)}")
    result_information_epoch = dict()
    result_base_read_epoch = dict()
    result_per_worker_file_epoch = dict()
    epoch += 1

for line in text_file:
    match = re.search(r"Epoch (\d)/\d", line)
    if match:
        if int(match.group(1)) == epoch + 1:
            end_of_epoch()

    match = re.search(r"Sender " + workers + r" informs the placement of file " + files, line)
    if match:
        if match.group(2) not in result_information_epoch:
            result_information_epoch[match.group(2)] = set()
        if match.group(2) in result_information:
            print(f"DOUBLE PLACEMENT: {match.group(2)}: {match.group(1)} and {result_information[match.group(2)]}")
        result_information_epoch[match.group(2)].add(match.group(1))

    #match = re.search(workers + r": client reading from level \d* file " + files + r" with offset: \d* and size: \d*", line)
    match = re.search(workers + r": opened file " + train_dir + files, line)
    if match:
        if match.group(2) not in result_base_read_epoch:
            result_base_read_epoch[match.group(2)] = set()
        result_base_read_epoch[match.group(2)].add(match.group(1))
        
        if match.group(1) not in result_per_worker_file_epoch:
            result_per_worker_file_epoch[match.group(1)] = set()
        result_per_worker_file_epoch[match.group(1)].add(match.group(2))

    match = re.search(workers + r": Found file: " + files + r" at worker: " + workers, line)
    if match:
        if match.group(2) not in result_found:
            result_found[match.group(2)] = set()
        result_found[match.group(2)].add((match.group(1), match.group(3)))

end_of_epoch()

all_files = list(range(n_files))

print("\n\n\nWhich files were informed by which workers:")
for train_file in sorted(result_information):
    print(f"\tFile {train_file} was informed by worker(s): {result_information[train_file]}")

print("\n\n\nWhich files were base read by which workers:")
for train_file in sorted(result_base_read):
    if int(train_file.split('-')[1]) in all_files:
            all_files.remove(int(train_file.split('-')[1]))
    print(f"\tFound file {train_file} base read by worker(s): {result_base_read[train_file]}")

print(f"\n\n\nFiles not accessed during training:")
print(sorted(all_files))

print(f"\n\n\nFiles found in pairs (asked for, found in)")
print(result_found)