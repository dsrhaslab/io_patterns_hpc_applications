#!/bin/bash
#SBATCH -J download_cifar       # Job name
#SBATCH -o myjob.out%j   # Name of stdout output file
#SBATCH -e myjob.err%j   # Name of stderr error file
#SBATCH -N 1                  # Total # of nodes (must be 1 for serial)
#SBATCH -n 1                  # Total # of mpi tasks (should be 1 for serial)
#SBATCH -t 24:00:00           # Run time (hh:mm:ss)
#SBATCH -p flex

module load python3/3.9.2

source ~/tf-venv/bin/activate

python /work2/10444/andre_l_ferreira/frontera/ScriptVault/TFScripts/models/official-models-2.1.0/official/r1/resnet/cifar10_download_and_extract.py --data_dir=$SCRATCH