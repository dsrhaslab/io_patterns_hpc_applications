#!/bin/bash

nodes=($(scontrol show hostnames ${SLURM_JOB_NODELIST} | sort | uniq ))
numnodes=${#nodes[@]}
last=$(( $numnodes - 1 ))
out="$(getent hosts ${nodes[0]} | awk '{print $1}')"
for i in $(seq 0 $last )
do
        ip="$(getent hosts ${nodes[$i]} | awk '{print $1}' | head -1)"

        if [[ $ip == "::1" ]]
        then
            ip="$(hostname -I)"
        fi

        echo -n $ip

	[[ $i != $last ]] && echo -n ","
done
