#!/bin/bash
#SBATCH -J dist-monarch       # Job name
#SBATCH -o test_rita_alexnet_2e_4nodes.out%j   # Name of stdout output file
#SBATCH -e test_rita_alexnet_2e_4nodes.err%j   # Name of stderr error file
#SBATCH -N 4                  # Total # of nodes (must be 1 for serial)
#SBATCH -n 4                  # Total # of mpi tasks (should be 1 for serial)
#SBATCH -t 12:00:00           # Run time (hh:mm:ss)
#SBATCH --account=i20240002g
#SBATCH --partition=normal-a100-40


#PROFILE_PATH=/etc/profile

WRKS_ADDRS="$(./get_ips_deucalion.sh)"
echo ${WRKS_ADDRS}
nodes=($(scontrol show hostnames ${SLURM_JOB_NODELIST} | sort | uniq ))
numnodes=${#nodes[@]}
last=$(( $numnodes - 1 ))

SINGLE_JOB_SCRIPT_NAME=run_wrapper_rita.sh
MODEL_ID=5 #0-vgg19, 1-incenptionv3, 2-shufflenet, 3-resnet18, 4-lenet, 5-alexnet SÓ O RESNET É QUE NÃO ESTÁ A FAZER MAU SHARDING
BATCH_SIZE=64
N_EPOCHS=2
DISTRIBUTION_STRATEGY="multi_worker_mirrored" # "mirrored", "one_device", "parameter_server", "multi_worker_mirrored"
DATASET="imagenet" # "imagenet" "openimages"
POLICY="distmonarch" # "hvac" "distmonarch" "none"
PROFILING="false" # "true" "false"
DEBUG="false" # "true" "false"
TEST_TITLE=$MODEL_ID\_$N_EPOCHS\_$BATCH_SIZE\_$DATASET\_distdebug2

for i in $(seq 0 $last )
do
        ssh $(getent hosts ${nodes[$i]} | awk '{print $2}' | head -1) """
        export WRKS_ADDRS=${WRKS_ADDRS};
        export TEST_TITLE=${TEST_TITLE};
        export HOME_DIR=/projects/I20240002/andrelucena;
        export WORK_DIR=/projects/I20240002/andrelucena;
        export SCRATCH=/projects/I20240002/andrelucena;
        export NODE_LOCAL_STORAGE="/tmp";
        export MACHINE="deucalion";
        module load Boost/1.76.0 CUDA/12.4.0 hwloc/2.4.1 NCCL/2.10.3 cuDNN/8.2.1 cmake/3.21.3 GCCcore/10.3.0 GDB;
        module load Python/3.9.5;
        module load valgrind;
        source /projects/I20240002/andrelucena/tensorflow-venv2/bin/activate;
        cd ${SCRIPT_DIR}; 
        ./${SINGLE_JOB_SCRIPT_NAME} ${i} ${MODEL_ID} ${BATCH_SIZE} ${N_EPOCHS} ${DISTRIBUTION_STRATEGY} ${DATASET} ${POLICY} ${PROFILING} ${DEBUG}""" &
        pids[${i}]=$!
done
# wait for all processes to finish
for pid in ${pids[*]}
do 
        wait $pid 
done

echo "Finished multi_run_wrapper.sh"