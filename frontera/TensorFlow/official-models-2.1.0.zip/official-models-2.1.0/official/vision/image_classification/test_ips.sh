#!/bin/bash

nodes=($(scontrol show hostnames ${SLURM_JOB_NODELIST} | sort | uniq ))
numnodes=${#nodes[@]}
last=$(( $numnodes - 1 ))
out="$(getent hosts ${nodes[0]} | awk '{print $1}')"
ipv6_regex="^fe80::.*"
#ipv4_regex="^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"
ipv4_regex="^([0-9]{1,3}\.){3}[0-9]{1,3}$"
for i in $(seq 0 $last )
do
        ip="$(getent hosts ${nodes[$i]} | awk '{print $1}' | head -1)"

        if [[ ! $ip =~ $ipv4_regex ]]
        then
            ip="$(hostname -I | awk '{print $1}')"
        fi

        echo -n $ip

	[[ $i != $last ]] && echo -n ","
done

