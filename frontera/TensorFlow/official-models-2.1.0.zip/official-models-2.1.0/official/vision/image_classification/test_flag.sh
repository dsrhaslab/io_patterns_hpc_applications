#!/bin/bash
#SBATCH -J test-flags       # Job name
#SBATCH -o test-flags.out%j   # Name of stdout output file
#SBATCH -e test-flags.err%j   # Name of stderr error file
#SBATCH -N 1                  # Total # of nodes (must be 1 for serial)
#SBATCH -n 1                  # Total # of mpi tasks (should be 1 for serial)
#SBATCH -t 48:00:00           # Run time (hh:mm:ss)
#SBATCH --account=i20240002g
#SBATCH --partition=normal-a100-80

module load Python/3.9.5 # for slurm to use python correct version
module load CUDA/11.3.1 Boost/1.76.0 hwloc/2.4.1 NCCL/2.10.3 cuDNN/8.2.1 cmake/3.21.3 GCCcore/10.3.0

source /projects/I20240002/andrelucena/tensorflow-venv2/bin/activate

SCRATCH="/projects/I20240002/andrelucena"
export PYTHONPATH=$PYTHONPATH:$SCRATCH/ScriptVault/TFScripts/models/official-models-2.1.0

python sns_alexnet.py --helpfull