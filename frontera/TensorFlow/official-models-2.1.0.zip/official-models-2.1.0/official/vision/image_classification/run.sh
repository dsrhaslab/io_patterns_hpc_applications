#!/bin/bash

#SBATCH -J rt-distributed-single-job      # Job name
#SBATCH -p normal                         # Queue (partition) name
#SBATCH -N 1                              # Total # of nodes (must be 1 for serial)
#SBATCH -n 1                              # Total # of mpi tasks (should be 1 for serial)
#SBATCH -t 01:00:00                       # Run time (hh:mm:ss)

module load Python/3.8.2 # for slurm to use python correct version
source $HOME/tensorflow-venv2/bin/activate
SCRATCH="/fs/scratch/franl08"
echo $HOME
echo $SCRATCH
#ml load NCCL/2.9.9-CUDA-11.3.1 cuDNN/8.2.1.32-CUDA-11.3.1  CMake/3.24.2-GCCcore-9.1.0 hwloc/1.11.12-GCCcore-9.1.0 GCC/9.1.0-2.32 GCCcore/9.1.0 Boost/1.74.0-GCC-9.1.0
#module load cuda/11.3 cudnn nccl # frontera
#module load CUDA/11.3 # for slurm
#module load cuDNN
#module load NCCL/2.9.9
#module load hwloc/1.11.12-GCCcore-9.1.0 # novo
#module load CMake/3.24.2-GCCcore-9.1.0 # novo
#module load Boost/1.79.0-GCC-11.2.0
#module load gcc
#export CXX=/opt/apps/gcc/9.1.0/bin/g++
#export CC=/opt/apps/gcc/9.1.0/bin/gcc
export CC=/opt/ohpc/pub/macc/modules/software/GCCcore/9.1.0/bin/gcc
export CXX=/opt/ohpc/pub/macc/modules/software/GCCcore/9.1.0/bin/g++
export INSTALL_DIR=$SCRATCH/dependencies
export MONARCH_DIR=$SCRATCH/DistMonarch/pastor/build
export MONARCH_CONFIGS_PATH=$SCRATCH/DistMonarch/configurations/slurm/tf_placement_100g_disk.yaml
rm -r /tmp/100g_tfrecords/
rm -r /tmp/middleware_output
ml load NCCL/2.9.9-CUDA-11.3.1 cuDNN/8.2.1.32-CUDA-11.3.1  CMake/3.24.2-GCCcore-9.1.0 hwloc/1.11.12-GCCcore-9.1.0 GCC/9.1.0-2.32 GCCcore/9.1.0 Boost/1.74.0-GCC-9.1.0
#cp /scratch1/09111/mbbm/lixo_60.txt /dev/shm
#python3.6 ~/creator.py
export PYTHONPATH=$PYTHONPATH:$SCRATCH/ScriptVault/TFScripts/models/official-models-2.1.0
#export WRKS_ADDRS="192.168.44.122,192.168.44.128,192.168.44.141,192.168.44.144,192.168.44.145,192.168.44.159"
export WRKS_ADDRS=$($SCRATCH/ScriptVault/TFScripts/models/official-models-2.1.0/official/vision/image_classification/get_ips_slurm.sh)
echo $WRKS_ADDRS
TASK_INDEX=$1
BATCH_SIZE=$2
MODEL=""
EPOCHS=2
#DATA_DIR="/scratch1/09111/mbbm/100g_tfrecords"
DATA_DIR="$SCRATCH/100g_tfrecords"
export TASK_ID=$TASK_INDEX

if [ $TASK_INDEX == 0 ]
then
	MODEL="sns_vgg19.py"
        EPOCHS=2

elif [ $TASK_INDEX == 1 ]
then
        MODEL="sns_inceptionv3.py"
        EPOCHS=2 #5

elif [ $TASK_INDEX == 2 ]
then
        MODEL="sns_shufflenet.py"
        EPOCHS=2 #10 8

elif [ $TASK_INDEX == 3 ]
then
        MODEL="sns_resnet18.py"
        EPOCHS=2 #10

elif [ $TASK_INDEX == 4 ]
then
        MODEL="sns_lenet.py"
        EPOCHS=2 #10 20

elif [ $TASK_INDEX == 5 ]
then
        MODEL="sns_alexnet.py"
        EPOCHS=2 #20
fi

EPOCHS=2


LOG_PATH="/tmp/log_$TASK_INDEX.txt"

#echo -e "$SCRIPT"
#nvidia-smi --query-gpu=utilization.gpu,utilization.memory,memory.total,memory.free,memory.used --format=csv -l 1 -f /tmp/nvidia-smi_${TASK_INDEX}.csv &
LD_PRELOAD=/fs/scratch/franl08/DistMonarch/pastor/build/libmonarch.so python $MODEL --skip_eval --train_epochs=$EPOCHS --batch_size=$BATCH_SIZE --model_dir="/tmp/checkpointing" --data_dir=$DATA_DIR --num_gpus=1 # |& tee $LOG_PATH  
#python $MODEL --skip_eval --train_epochs=$EPOCHS --batch_size=$BATCH_SIZE --model_dir="/tmp/checkpointing" --data_dir=$DATA_DIR --num_gpus=1
