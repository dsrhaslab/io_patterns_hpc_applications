#!/bin/bash

nodes=($(scontrol show hostnames ${SLURM_JOB_NODELIST} | sort | uniq ))
numnodes=${#nodes[@]}
last=$(( $numnodes - 1 ))
out="$(getent hosts ${nodes[0]} | awk '{print $1}')"
ipv4_regex="^([0-9]{1,3}\.){3}[0-9]{1,3}$"
for i in $(seq 0 $last )
do
        #ip="$(getent hosts ${nodes[$i]} | awk '{print $1}' | head -1)"

        #if [[ ! $ip =~ $ipv4_regex ]]
        #then
        #    ip="$(hostname -I | awk '{print $1}')"
        #fi

        #ip="$(ssh $(getent hosts ${nodes[$i]} | awk '{print $2}' | head -1) "hostname -I | cut -d ' ' -f1")"
        ip="$(ssh $(getent hosts ${nodes[$i]} | awk '{print $2}' | head -1) "ip -4 -o a | grep ib0 | awk '{print \$4}' | cut -d '/' -f1")"
        echo -n $ip

	[[ $i != $last ]] && echo -n ","
done

